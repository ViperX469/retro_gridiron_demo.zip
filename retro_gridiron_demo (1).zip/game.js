
const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

const passBtn = document.getElementById('pass-btn');
const dodgeBtn = document.getElementById('dodge-btn');
const messageEl = document.getElementById('message');

const FIELD_WIDTH = canvas.width;
const FIELD_HEIGHT = canvas.height;

const PLAYER_SIZE = 10;

const TEAM_COLORS = ['red', 'blue'];

let team1Score = 0;
let team2Score = 0;

let possession = 1; // 1 or 2

let ball = {
  x: 50,
  y: FIELD_HEIGHT / 2,
  radius: 5,
  vx: 0,
  vy: 0,
  flying: false
};

function randomName() {
  const syllables = ['ka','to','mi','su','lo','ra','ne','zi','po','de','fi','lu','na','ki'];
  return syllables[Math.floor(Math.random()*syllables.length)]+
         syllables[Math.floor(Math.random()*syllables.length)];
}

function Player(team, x, y) {
  this.team = team;
  this.x = x;
  this.y = y;
  this.name = randomName();
  this.rating = 2.5; // fixed 2.5 stars
  this.hasBall = false;
}

let basicTeam1 = [];
let basicTeam2 = [];

function setupTeams() {
  basicTeam1 = [];
  basicTeam2 = [];
  for(let i=0; i<5; i++) {
    basicTeam1.push(new Player(1, 40, 50 + i*30));
    basicTeam2.push(new Player(2, FIELD_WIDTH-40, 50 + i*30));
  }
  basicTeam1[0].hasBall = true;
  ball.x = basicTeam1[0].x + 10;
  ball.y = basicTeam1[0].y;
  possession = 1;
  updateScoreboard();
  messageEl.textContent = "Basic Team 1 has possession.";
}

function updateScoreboard() {
  document.getElementById('score1').textContent = team1Score;
  document.getElementById('score2').textContent = team2Score;
}

function drawField() {
  ctx.fillStyle = '#0b5e00';
  ctx.fillRect(0, 0, FIELD_WIDTH, FIELD_HEIGHT);
  ctx.strokeStyle = '#eee';
  ctx.lineWidth = 1;
  for(let x=0; x<=FIELD_WIDTH; x+=40) {
    ctx.beginPath();
    ctx.moveTo(x,0);
    ctx.lineTo(x,FIELD_HEIGHT);
    ctx.stroke();
  }
  for(let y=0; y<=FIELD_HEIGHT; y+=40) {
    ctx.beginPath();
    ctx.moveTo(0,y);
    ctx.lineTo(FIELD_WIDTH,y);
    ctx.stroke();
  }
}

function drawPlayer(player) {
  ctx.fillStyle = TEAM_COLORS[player.team-1];
  ctx.fillRect(player.x - PLAYER_SIZE/2, player.y - PLAYER_SIZE/2, PLAYER_SIZE, PLAYER_SIZE);
  if(player.hasBall) {
    ctx.beginPath();
    ctx.fillStyle = 'brown';
    ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI*2);
    ctx.fill();
  }
}

function draw() {
  drawField();
  basicTeam1.forEach(drawPlayer);
  basicTeam2.forEach(drawPlayer);
}

function passBall() {
  if(ball.flying) {
    messageEl.textContent = "Ball is already in the air! Wait for it to land.";
    return;
  }
  let passer = possession === 1 ? basicTeam1.find(p=>p.hasBall) : basicTeam2.find(p=>p.hasBall);
  if(!passer) return;
  // Find target receiver randomly on same team but not passer
  let team = possession === 1 ? basicTeam1 : basicTeam2;
  let receivers = team.filter(p => p !== passer);
  let target = receivers[Math.floor(Math.random()*receivers.length)];
  messageEl.textContent = `${passer.name} passes to ${target.name}`;
  ball.flying = true;
  // Animate ball flying over 1 second
  let frames = 30;
  let dx = (target.x - ball.x)/frames;
  let dy = (target.y - ball.y)/frames;
  let frame = 0;
  let interval = setInterval(()=>{
    ball.x += dx;
    ball.y += dy;
    frame++;
    if(frame >= frames) {
      clearInterval(interval);
      ball.flying = false;
      passer.hasBall = false;
      target.hasBall = true;
      ball.x = target.x + 10;
      ball.y = target.y;
      // Random chance for touchdown (simplified)
      if(possession === 1 && ball.x > FIELD_WIDTH - 60) {
        team1Score++;
        messageEl.textContent = `${target.name} scores for Basic Team 1!`;
        updateScoreboard();
        resetAfterScore();
      } else if(possession === 2 && ball.x < 60) {
        team2Score++;
        messageEl.textContent = `${target.name} scores for Basic Team 2!`;
        updateScoreboard();
        resetAfterScore();
      } else {
        messageEl.textContent = `${target.name} caught the ball.`;
      }
    }
  }, 33);
}

function dodge() {
  let player = possession === 1 ? basicTeam1.find(p=>p.hasBall) : basicTeam2.find(p=>p.hasBall);
  if(!player || ball.flying) {
    messageEl.textContent = "Can't dodge now.";
    return;
  }
  let direction = (possession === 1) ? 20 : -20;
  player.x += direction;
  ball.x += direction;
  messageEl.textContent = `${player.name} dodged!`;
  // Check touchdown for dodge movement too
  if(possession === 1 && player.x > FIELD_WIDTH - 60) {
    team1Score++;
    messageEl.textContent = `${player.name} scores for Basic Team 1!`;
    updateScoreboard();
    resetAfterScore();
  } else if(possession === 2 && player.x < 60) {
    team2Score++;
    messageEl.textContent = `${player.name} scores for Basic Team 2!`;
    updateScoreboard();
    resetAfterScore();
  }
}

function resetAfterScore() {
  // Swap possession and reset players
  possession = possession === 1 ? 2 : 1;
  setupTeams();
}

passBtn.addEventListener('click', passBall);
dodgeBtn.addEventListener('click', dodge);

setupTeams();

function gameLoop() {
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();
